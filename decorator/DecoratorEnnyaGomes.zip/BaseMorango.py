from MilkShake import MilkShake

class BaseMorango(MilkShake):
    def monta(self):
        print("Fazendo milkshake de morango...")