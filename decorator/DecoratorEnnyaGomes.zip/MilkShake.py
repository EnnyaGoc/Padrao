from abc import ABC, abstractmethod

class MilkShake(ABC):
    @abstractmethod
    def monta(self):
        pass