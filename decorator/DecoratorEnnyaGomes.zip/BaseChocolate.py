from MilkShake import MilkShake

class BaseChocolate(MilkShake):
    def monta(self):
        print("Fazendo milkshake de chocolate...")