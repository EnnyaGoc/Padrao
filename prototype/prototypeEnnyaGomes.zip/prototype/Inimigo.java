public interface Inimigo extends Cloneable {
    public Inimigo inimigoclone();
    public void ataque();
}