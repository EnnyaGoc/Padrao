class Cafeteira:
    def ligar(self):
        print("Cafeteira ligada!")

    def desligar(self):
        print("Cafeteira desligada!")