class CaixaDeSom:
    def ligar(self):
        print("Caixa de som ligada!")

    def desligar(self):
        print("Caixa de som desligada!")

    def aumentar_volume(self):
        print("Volume da caixa de som aumentado!")

    def diminuir_volume(self):
        print("Volume da caixa de som diminuído!")
