public class Estrategia2 implements IEstrategia{
    public void executar(){
        System.out.println("executando estrategia defensiva");
    }
}