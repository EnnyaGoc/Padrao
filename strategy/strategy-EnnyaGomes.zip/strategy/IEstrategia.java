public interface IEstrategia{
    public void executar();
}