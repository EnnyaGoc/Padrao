public class Estrategia3 implements IEstrategia{
    public void executar(){
        System.out.println("executando estrategia de suporte");
    }
}