public class Estrategia1 implements IEstrategia{
    public void executar(){
        System.out.println("executando estrategia agressiva");
    }
}