class Carros:

    def alugaCarro(self, carro, data):
        print("carro alugado") 
        pass