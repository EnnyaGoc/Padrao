
class Voos:
    def verificaDisponibilidade(self, data, destino):
        print("disponibilidade verificada")
        pass
    
    def reservaVoo(self, data, destino):
        print("voo reservado")
        pass