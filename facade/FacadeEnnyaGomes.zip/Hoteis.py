class Hoteis:
    def verificaDisponibilidade(self, hotel, data):
        print("disponibilidade verificada")
        pass

    def reservaQuarto(self, hotel, data):
        print("quarto reservado") 
        pass