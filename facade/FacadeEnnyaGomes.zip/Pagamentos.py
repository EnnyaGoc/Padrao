class Pagamentos:
    def realizarPagamento(self, cartao, valor):
        print("pagamento realizado")
        pass