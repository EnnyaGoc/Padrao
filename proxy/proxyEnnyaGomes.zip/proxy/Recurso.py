class Recurso:
    def acessar(self):
        return "Acessando os recursos sensíveis"
