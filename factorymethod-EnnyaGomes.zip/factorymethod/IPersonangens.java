interface IPersonagens{
    void lutando();
    void habilidade();
    void equipamento();
}