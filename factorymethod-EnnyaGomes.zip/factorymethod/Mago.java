public class Mago implements IPersonagens{
    public void lutando(){
        System.out.println("Mago lutando...");
    }

      public void habilidade(){
        System.out.println("habilidade de mago");
    }

    public void equipamento(){
        System.out.println("varinha mágica");
    }
}