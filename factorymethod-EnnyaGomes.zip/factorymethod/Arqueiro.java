public class Arqueiro implements IPersonagens{
    public void lutando(){
        System.out.println("arqueiro lutando...");
    }

    public void habilidade(){
        System.out.println("habilidade de arqueiro");
    }

    public void equipamento(){
        System.out.println("arco e flecha");
    }
}