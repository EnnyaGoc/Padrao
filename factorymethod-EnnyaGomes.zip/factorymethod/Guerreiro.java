public class Guerreiro implements IPersonagens{
    public void lutando(){
        System.out.println("guerreiro lutando...");
    }

      public void habilidade(){
        System.out.println("habilidade de guerreiro");
    }

    public void equipamento(){
        System.out.println("espada e escudo");
    }
}