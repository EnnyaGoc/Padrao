public interface Tarefa {
    void concluir();
    void desfazer();
    boolean concluida();
}

